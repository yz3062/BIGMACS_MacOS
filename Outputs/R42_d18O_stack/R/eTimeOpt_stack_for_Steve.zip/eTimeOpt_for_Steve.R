library(astrochron)
library(readxl)

ex <- read_excel('Stack_untuned_uniform_age_exclusion_expanded_1172_removed_Hobart2023.xlsx')
# evaluate precession & eccentricity power, and precession modulations
res=eTimeOpt(ex,win=20,step=1,fit=1,output=1)
